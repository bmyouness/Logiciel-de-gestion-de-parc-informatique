﻿using System;
using System.Collections.Generic;

namespace ParcInformatique.Models;

public partial class Matériel
{
    public int IdMateriel { get; set; }

    public string? NomMachine { get; set; }

    public string? AdresseIp { get; set; }

    public string? Description { get; set; }

    public DateTime? DateMiseEnService { get; set; }

    public int IdTypeMateriel { get; set; }

    public int IdClient { get; set; }

    public virtual Client IdClientNavigation { get; set; } = null!;

    public virtual TypeMateriel IdTypeMaterielNavigation { get; set; } = null!;
}
