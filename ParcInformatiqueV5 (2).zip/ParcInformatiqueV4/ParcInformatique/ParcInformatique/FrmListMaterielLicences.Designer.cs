﻿namespace ParcInformatique
{
    partial class FrmListMaterielLicences
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBox1 = new ListBox();
            listBox2 = new ListBox();
            TxtListMateriel = new Label();
            TxtListLicence = new Label();
            BtnAjoutMateriel = new Button();
            BtnModifMateriel = new Button();
            BtnSuppressionMateriel = new Button();
            BtnAjouterLicence = new Button();
            BtnModifLicence = new Button();
            BtnSupprLicence = new Button();
            BtnRetour = new Button();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.Location = new Point(28, 87);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(218, 264);
            listBox1.TabIndex = 0;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.Location = new Point(385, 87);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(218, 264);
            listBox2.TabIndex = 1;
            listBox2.SelectedIndexChanged += listBox2_SelectedIndexChanged;
            // 
            // TxtListMateriel
            // 
            TxtListMateriel.AutoSize = true;
            TxtListMateriel.Location = new Point(28, 51);
            TxtListMateriel.Name = "TxtListMateriel";
            TxtListMateriel.Size = new Size(161, 20);
            TxtListMateriel.TabIndex = 2;
            TxtListMateriel.Text = "Liste Matériel du Client";
            TxtListMateriel.Click += label1_Click;
            // 
            // TxtListLicence
            // 
            TxtListLicence.AutoSize = true;
            TxtListLicence.Location = new Point(385, 51);
            TxtListLicence.Name = "TxtListLicence";
            TxtListLicence.Size = new Size(185, 20);
            TxtListLicence.TabIndex = 3;
            TxtListLicence.Text = "Liste des licences du Client";
            // 
            // BtnAjoutMateriel
            // 
            BtnAjoutMateriel.Location = new Point(264, 87);
            BtnAjoutMateriel.Name = "BtnAjoutMateriel";
            BtnAjoutMateriel.Size = new Size(94, 43);
            BtnAjoutMateriel.TabIndex = 5;
            BtnAjoutMateriel.Text = "Ajouter";
            BtnAjoutMateriel.UseVisualStyleBackColor = true;
            BtnAjoutMateriel.Click += BtnAjout_Click;
            // 
            // BtnModifMateriel
            // 
            BtnModifMateriel.Location = new Point(264, 203);
            BtnModifMateriel.Name = "BtnModifMateriel";
            BtnModifMateriel.Size = new Size(94, 43);
            BtnModifMateriel.TabIndex = 6;
            BtnModifMateriel.Text = "Modifier";
            BtnModifMateriel.UseVisualStyleBackColor = true;
            BtnModifMateriel.Click += BtnModifMateriel_Click;
            // 
            // BtnSuppressionMateriel
            // 
            BtnSuppressionMateriel.Location = new Point(264, 308);
            BtnSuppressionMateriel.Name = "BtnSuppressionMateriel";
            BtnSuppressionMateriel.Size = new Size(94, 43);
            BtnSuppressionMateriel.TabIndex = 7;
            BtnSuppressionMateriel.Text = "Supprimer";
            BtnSuppressionMateriel.UseVisualStyleBackColor = true;
            BtnSuppressionMateriel.Click += BtnSuppressionMateriel_Click;
            // 
            // BtnAjouterLicence
            // 
            BtnAjouterLicence.Location = new Point(620, 87);
            BtnAjouterLicence.Name = "BtnAjouterLicence";
            BtnAjouterLicence.Size = new Size(94, 43);
            BtnAjouterLicence.TabIndex = 8;
            BtnAjouterLicence.Text = "Ajouter";
            BtnAjouterLicence.UseVisualStyleBackColor = true;
            // 
            // BtnModifLicence
            // 
            BtnModifLicence.Location = new Point(620, 203);
            BtnModifLicence.Name = "BtnModifLicence";
            BtnModifLicence.Size = new Size(94, 43);
            BtnModifLicence.TabIndex = 9;
            BtnModifLicence.Text = "Modifier";
            BtnModifLicence.UseVisualStyleBackColor = true;
            // 
            // BtnSupprLicence
            // 
            BtnSupprLicence.Location = new Point(620, 308);
            BtnSupprLicence.Name = "BtnSupprLicence";
            BtnSupprLicence.Size = new Size(94, 43);
            BtnSupprLicence.TabIndex = 10;
            BtnSupprLicence.Text = "Supprimer";
            BtnSupprLicence.UseVisualStyleBackColor = true;
            BtnSupprLicence.Click += BtnSupprLicence_Click;
            // 
            // BtnRetour
            // 
            BtnRetour.Location = new Point(28, 409);
            BtnRetour.Name = "BtnRetour";
            BtnRetour.Size = new Size(94, 29);
            BtnRetour.TabIndex = 11;
            BtnRetour.Text = "RETOUR";
            BtnRetour.UseVisualStyleBackColor = true;
            // 
            // FrmListMaterielLicences
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BtnRetour);
            Controls.Add(BtnSupprLicence);
            Controls.Add(BtnModifLicence);
            Controls.Add(BtnAjouterLicence);
            Controls.Add(BtnSuppressionMateriel);
            Controls.Add(BtnModifMateriel);
            Controls.Add(BtnAjoutMateriel);
            Controls.Add(TxtListLicence);
            Controls.Add(TxtListMateriel);
            Controls.Add(listBox2);
            Controls.Add(listBox1);
            Name = "FrmListMaterielLicences";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBox1;
        private ListBox listBox2;
        private Label TxtListMateriel;
        private Label TxtListLicence;
        private Button BtnAjoutMateriel;
        private Button BtnModifMateriel;
        private Button BtnSuppressionMateriel;
        private Button BtnAjouterLicence;
        private Button BtnModifLicence;
        private Button BtnSupprLicence;
        private Button BtnRetour;
    }
}