﻿using System;
using System.Windows.Forms;
using ParcInformatique.Models;

namespace ParcInformatique
{
    public partial class FrmAjoutClient : Form
    {
        // null => AJOUT ; valeur => MODIF
        private int? _clientId = null;
        private bool modif_true = false;

        public FrmAjoutClient()
        {
            InitializeComponent();
        }

        // OUVERTURE EN MODE MODIFICATION AVEC UN CLIENT EXISTANT
        public FrmAjoutClient(Client client)
        {
            InitializeComponent();
            modif_true = true;
            _clientId = client.IdClient;

            // Pré-remplissage
            TxtBoxSiret.Text = client.Siret;
            TxtBoxEntreprise.Text = client.NomEntreprise;
            TxtBoxJuridique.Text = client.FormeJuridique;

            Text = "Modifier un client";
            // Si ton bouton s’appelle autrement dans le Designer, adapte ce nom :
            // BtnAddClient.Text = "Modifier";
        }

        private void label2_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void FrmAjoutClient_Load(object sender, EventArgs e) { }

        // === AJOUT / MODIFICATION ===
        private void BtnAddClient_Click(object sender, EventArgs e)
        {
            try
            {
                using var db = new ParcInforYounessMaximeContext();

                if (!modif_true || _clientId == null)
                {
                    // -------- AJOUT --------
                    var nouveau = new Client
                    {
                        Siret = TxtBoxSiret.Text,
                        NomEntreprise = TxtBoxEntreprise.Text,
                        FormeJuridique = TxtBoxJuridique.Text
                    };

                    db.Clients.Add(nouveau);
                }
                else
                {
                    // -------- MODIFICATION --------
                    var existant = db.Clients.Find(_clientId.Value);
                    if (existant == null)
                    {
                        MessageBox.Show("Client introuvable.");
                        return;
                    }

                    existant.Siret = TxtBoxSiret.Text;
                    existant.NomEntreprise = TxtBoxEntreprise.Text;
                    existant.FormeJuridique = TxtBoxJuridique.Text;
                }

                db.SaveChanges();
                MessageBox.Show("Client sauvegardé ");
                DialogResult = DialogResult.OK; // pour rafraîchir la liste à la fermeture
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message);
            }
        }

        private void TxtBoxSiret_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
