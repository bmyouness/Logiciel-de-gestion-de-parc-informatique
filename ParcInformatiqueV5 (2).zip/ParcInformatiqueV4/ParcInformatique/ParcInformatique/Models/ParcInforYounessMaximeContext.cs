﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ParcInformatique.Models;

public partial class ParcInforYounessMaximeContext : DbContext
{
    public ParcInforYounessMaximeContext()
    {
    }

    public ParcInforYounessMaximeContext(DbContextOptions<ParcInforYounessMaximeContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Client> Clients { get; set; }

    public virtual DbSet<LicenceLogiciel> LicenceLogiciels { get; set; }

    public virtual DbSet<Matériel> Matériels { get; set; }

    public virtual DbSet<TypeMateriel> TypeMateriels { get; set; }

    public virtual DbSet<UtilisateurAd> UtilisateurAds { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=2a03:5840:111:1024:508f:fc67:4795:f4d3;Database=ParcInforYounessMaxime;User ID=sa;Password=erty64%;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Client>(entity =>
        {
            entity.HasKey(e => e.IdClient).HasName("PK__Client__C1961B336C2FBB7A");

            entity.ToTable("Client");

            entity.Property(e => e.FormeJuridique)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.NomEntreprise)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Siret)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<LicenceLogiciel>(entity =>
        {
            entity.HasKey(e => e.IdLicence).HasName("PK__Licence___E01698469E3121D4");

            entity.ToTable("Licence_Logiciel");

            entity.Property(e => e.CleProduit)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.NomProduit)
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.IdClientNavigation).WithMany(p => p.LicenceLogiciels)
                .HasForeignKey(d => d.IdClient)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Licence_L__IdCli__2F10007B");
        });

        modelBuilder.Entity<Matériel>(entity =>
        {
            entity.HasKey(e => e.IdMateriel).HasName("PK__Matériel__9435CFD7254D1DBC");

            entity.ToTable("Matériel");

            entity.Property(e => e.AdresseIp)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("AdresseIP");
            entity.Property(e => e.Description)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.NomMachine)
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.IdClientNavigation).WithMany(p => p.Matériels)
                .HasForeignKey(d => d.IdClient)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Matériel__IdClie__29572725");

            entity.HasOne(d => d.IdTypeMaterielNavigation).WithMany(p => p.Matériels)
                .HasForeignKey(d => d.IdTypeMateriel)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Matériel__IdType__286302EC");
        });

        modelBuilder.Entity<TypeMateriel>(entity =>
        {
            entity.HasKey(e => e.IdTypeMateriel).HasName("PK__Type_Mat__6174A56689F41148");

            entity.ToTable("Type_Materiel");

            entity.Property(e => e.NomMateriel)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<UtilisateurAd>(entity =>
        {
            entity.HasKey(e => e.IdUtilisateurAd).HasName("PK__Utilisat__0C7BB8C58E93B648");

            entity.ToTable("UtilisateurAD");

            entity.Property(e => e.IdUtilisateurAd).HasColumnName("IdUtilisateurAD");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.IdentifiantAd)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("IdentifiantAD");
            entity.Property(e => e.NomAffiche)
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.IdClientNavigation).WithMany(p => p.UtilisateurAds)
                .HasForeignKey(d => d.IdClient)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Utilisate__IdCli__2C3393D0");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
