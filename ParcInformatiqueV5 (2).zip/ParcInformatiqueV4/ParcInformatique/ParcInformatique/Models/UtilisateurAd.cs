﻿using System;
using System.Collections.Generic;

namespace ParcInformatique.Models;

public partial class UtilisateurAd
{
    public int IdUtilisateurAd { get; set; }

    public string? IdentifiantAd { get; set; }

    public string? NomAffiche { get; set; }

    public string? Email { get; set; }

    public int IdClient { get; set; }

    public virtual Client IdClientNavigation { get; set; } = null!;
}
