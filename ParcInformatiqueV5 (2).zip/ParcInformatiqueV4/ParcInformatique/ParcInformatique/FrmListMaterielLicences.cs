﻿using ParcInformatique.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParcInformatique
{
    public partial class FrmListMaterielLicences : Form
    {
        public FrmListMaterielLicences()
        {
            InitializeComponent();
            ChargerLaListeMateriel();
            ChargerLaListeLicence();
        }

        private void ChargerLaListeMateriel()
        {
            try
            {
                Matériel selectedMateriel = (Matériel)listBox1.SelectedItem;

                listBox1.Items.Clear();
                using (ParcInforYounessMaximeContext db = new ParcInforYounessMaximeContext())
                {
                    List<Matériel> matériels = db.Matériels.ToList();
                    listBox1.DisplayMember = "NomMachine"; // On affiche le nom et le prénom de l'entreprise à l'utilisateur
                    listBox1.Items.AddRange(matériels.ToArray()); // Conversion de la liste en tableau
                }

                listBox1.SelectedItem = listBox1.Items.OfType<Matériel>().Where(o => o.IdMateriel == selectedMateriel?.IdMateriel).SingleOrDefault();

            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        private void ChargerLaListeLicence()
        {
            try
            {
                LicenceLogiciel selectedLicenceLogiciel = (LicenceLogiciel)listBox2.SelectedItem;

                listBox2.Items.Clear();
                using (ParcInforYounessMaximeContext db = new ParcInforYounessMaximeContext())
                {
                    List<LicenceLogiciel> LicenceLogiciel = db.LicenceLogiciels.ToList();
                    listBox2.DisplayMember = "NomProduit"; // On affiche le nom et le prénom de l'entreprise à l'utilisateur
                    listBox2.Items.AddRange(LicenceLogiciel.ToArray()); // Conversion de la liste en tableau
                }

                listBox2.SelectedItem = listBox2.Items.OfType<LicenceLogiciel>().Where(o => o.IdLicence == selectedLicenceLogiciel?.IdLicence).SingleOrDefault();

            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnAjout_Click(object sender, EventArgs e)
        {
            using var add_materiel = new FrmAjoutModifMateriel();
            if (add_materiel.ShowDialog() == DialogResult.OK) // attends que le form se ferme
            {
                ChargerLaListeMateriel(); // recharge la liste après ajout
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void BtnSuppressionMateriel_Click(object sender, EventArgs e)
        {
            {
                Matériel selectedMateriel = (Matériel)listBox1.SelectedItem;

                DialogResult dr = MessageBox.Show(
                    "Êtes-vous sûr de vouloir supprimer " + selectedMateriel.NomMachine + " ?",
                    "Êtes-vous sûr ?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dr == DialogResult.Yes)
                {
                    try
                    {
                        using (var db = new ParcInforYounessMaximeContext())
                        {
                            // Attache l’entité sélectionnée puis supprime
                            db.Matériels.Attach(selectedMateriel);
                            db.Matériels.Remove(selectedMateriel);
                            db.SaveChanges();
                        }

                        // Recharge la liste après suppression
                        ChargerLaListeMateriel();
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
        }

        private void BtnSupprLicence_Click(object sender, EventArgs e)
        {
            {
                LicenceLogiciel selectedLicenceLogiciel = (LicenceLogiciel)listBox2.SelectedItem;

                DialogResult dr = MessageBox.Show(
                    "Êtes-vous sûr de vouloir supprimer " + selectedLicenceLogiciel.NomProduit + " ?",
                    "Êtes-vous sûr ?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dr == DialogResult.Yes)
                {
                    try
                    {
                        using (var db = new ParcInforYounessMaximeContext())
                        {
                            // Attache l’entité sélectionnée puis supprime
                            db.LicenceLogiciels.Attach(selectedLicenceLogiciel);
                            db.LicenceLogiciels.Remove(selectedLicenceLogiciel);
                            db.SaveChanges();
                        }

                        // Recharge la liste après suppression
                        ChargerLaListeLicence();
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
        }

        private void BtnModifMateriel_Click(object sender, EventArgs e)
        {
            var selectedMatériel = listBox1.SelectedItem as Matériel;
            if (selectedMatériel == null)
            {
                MessageBox.Show("Sélectionne un Matériel d’abord !");
                return;
            }

            IdMateriel = selectedMatériel.IdMateriel;

            using var edit_client = new FrmAjoutClient(selectedMatériel);
            if (edit_Matériel.ShowDialog() == DialogResult.OK) // attends la fermeture
            {
                ChargerLaListeMateriel(); // recharge après modification
            }
        }
    }
}
