using System.Net.Sockets;
using ParcInformatique.Models;

namespace ParcInformatique
{
    public partial class FrmListClient : Form
    {
        public static int IdCompteClient
        {
            get;
            private set;
        }

        public FrmListClient()
        {
            InitializeComponent();
            ChargerLaListe();
        }

        private void ChargerLaListe()
        {
            try
            {
                Client selectedClient = (Client)LstBoxClient.SelectedItem;

                LstBoxClient.Items.Clear();
                using (ParcInforYounessMaximeContext db = new ParcInforYounessMaximeContext())
                {
                    List<Client> clients = db.Clients.ToList();
                    LstBoxClient.DisplayMember = "NomEntreprise"; // On affiche le nom et le pr�nom de l'entreprise � l'utilisateur
                    LstBoxClient.Items.AddRange(clients.ToArray()); // Conversion de la liste en tableau
                }

                LstBoxClient.SelectedItem = LstBoxClient.Items.OfType<Client>().Where(o => o.IdClient == selectedClient?.IdClient).SingleOrDefault();

            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        private void LstBoxClient_SelectedIndexChanged(object sender, EventArgs e)
        {

            //try
            //{
            //    Client client = (Client)LstBoxClient.SelectedItem;

            //    TxtNom.Text = client.NomEn;
            //    TxtPrenom.Text = technicien.Prenom;
            //    CmbSociete.SelectedItem = CmbSociete.Items.OfType<Societe>().Where(o => o.IdSociete == technicien.IdSociete).SingleOrDefault();

            //    BtnMettreAJour.Enabled = true;
            //}
            //catch (Exception exception)
            //{
            //    TxtNom.Text = "";
            //    TxtPrenom.Text = "";
            //    CmbSociete.SelectedItem = null;

            //    //MessageBox.Show(exception.Message);
            //}
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmAjoutClient add_client = new FrmAjoutClient();
            add_client.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            // IdCompteClient = selectedClient.Id;
            FrmAjoutClient Hebergement = new FrmAjoutClient();
            Hebergement.Show(); 
        }

        private void LstBoxClient_DoubleClick(object sender, EventArgs e)
        {
            FrmListMaterielLicences liste_materiel = new FrmListMaterielLicences();
            liste_materiel.Show();

        }

        private void BtnSuppClient_Click(object sender, EventArgs e)
        {

        }
    }
}
