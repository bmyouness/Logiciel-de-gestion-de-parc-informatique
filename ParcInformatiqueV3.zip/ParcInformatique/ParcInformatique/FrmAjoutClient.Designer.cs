﻿namespace ParcInformatique
{
    partial class FrmAjoutClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            TxtBoxSiret = new TextBox();
            TxtBoxEntreprise = new TextBox();
            TxtBoxJuridique = new TextBox();
            BtnAddClient = new Button();
            BtnModifClient = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(330, 50);
            label1.Name = "label1";
            label1.Size = new Size(54, 20);
            label1.TabIndex = 0;
            label1.Text = "Client :";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(46, 145);
            label2.Name = "label2";
            label2.Size = new Size(125, 20);
            label2.TabIndex = 1;
            label2.Text = "Numéro de Siret :";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(46, 207);
            label3.Name = "label3";
            label3.Size = new Size(151, 20);
            label3.TabIndex = 2;
            label3.Text = "Nom de l'entreprise : ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(46, 270);
            label4.Name = "label4";
            label4.Size = new Size(126, 20);
            label4.TabIndex = 3;
            label4.Text = "Forme Juridique : ";
            label4.Click += label4_Click;
            // 
            // TxtBoxSiret
            // 
            TxtBoxSiret.Location = new Point(228, 138);
            TxtBoxSiret.Name = "TxtBoxSiret";
            TxtBoxSiret.Size = new Size(205, 27);
            TxtBoxSiret.TabIndex = 4;
            // 
            // TxtBoxEntreprise
            // 
            TxtBoxEntreprise.Location = new Point(228, 207);
            TxtBoxEntreprise.Name = "TxtBoxEntreprise";
            TxtBoxEntreprise.Size = new Size(205, 27);
            TxtBoxEntreprise.TabIndex = 5;
            // 
            // TxtBoxJuridique
            // 
            TxtBoxJuridique.Location = new Point(228, 270);
            TxtBoxJuridique.Name = "TxtBoxJuridique";
            TxtBoxJuridique.Size = new Size(205, 27);
            TxtBoxJuridique.TabIndex = 6;
            // 
            // BtnAddClient
            // 
            BtnAddClient.Location = new Point(208, 392);
            BtnAddClient.Name = "BtnAddClient";
            BtnAddClient.Size = new Size(94, 29);
            BtnAddClient.TabIndex = 7;
            BtnAddClient.Text = "Ajouter !";
            BtnAddClient.UseVisualStyleBackColor = true;
            BtnAddClient.Click += BtnAddClient_Click;
            // 
            // BtnModifClient
            // 
            BtnModifClient.Location = new Point(478, 392);
            BtnModifClient.Name = "BtnModifClient";
            BtnModifClient.Size = new Size(94, 29);
            BtnModifClient.TabIndex = 8;
            BtnModifClient.Text = "Modifier !";
            BtnModifClient.UseVisualStyleBackColor = true;
            // 
            // FrmAjoutClient
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BtnModifClient);
            Controls.Add(BtnAddClient);
            Controls.Add(TxtBoxJuridique);
            Controls.Add(TxtBoxEntreprise);
            Controls.Add(TxtBoxSiret);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FrmAjoutClient";
            Text = "Form1";
            Load += FrmAjoutClient_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox TxtBoxSiret;
        private TextBox TxtBoxEntreprise;
        private TextBox TxtBoxJuridique;
        private Button BtnAddClient;
        private Button BtnModifClient;
    }
}