﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ParcInformatique.Models;

namespace ParcInformatique
{
    public partial class FrmAjoutClient : Form
    {
        public FrmAjoutClient()
        {
            InitializeComponent();
        }

        bool modif_true = false;
        public FrmAjoutClient(Client client)
        {
            InitializeComponent();
            modif_true = true;

            TxtBoxSiret.Text = client.Siret.ToString();
            TxtBoxEntreprise.Text = client.NomEntreprise.ToString();
            TxtBoxJuridique.Text = client.FormeJuridique.ToString();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FrmAjoutClient_Load(object sender, EventArgs e)
        {

        }

        private void BtnAddClient_Click(object sender, EventArgs e)
        {
            try
            {
                using var db = new ParcInforYounessMaximeContext();

                var client = new Client
                {
                    Siret = TxtBoxSiret.Text,
                    NomEntreprise = TxtBoxEntreprise.Text,
                    FormeJuridique = TxtBoxJuridique.Text
                };

                db.Clients.Add(client);
                db.SaveChanges();

                MessageBox.Show("Client ajouté avec succès ");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout du client : " + ex.Message);
            }
        }
    }
}
