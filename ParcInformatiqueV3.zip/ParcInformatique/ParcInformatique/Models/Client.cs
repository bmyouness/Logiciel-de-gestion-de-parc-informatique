﻿using System;
using System.Collections.Generic;

namespace ParcInformatique.Models;

public partial class Client
{
    public int IdClient { get; set; }

    public string? Siret { get; set; }

    public string? NomEntreprise { get; set; }

    public string? FormeJuridique { get; set; }

    public virtual ICollection<LicenceLogiciel> LicenceLogiciels { get; set; } = new List<LicenceLogiciel>();

    public virtual ICollection<Matériel> Matériels { get; set; } = new List<Matériel>();

    public virtual ICollection<UtilisateurAd> UtilisateurAds { get; set; } = new List<UtilisateurAd>();
}
