﻿using System;
using System.Collections.Generic;

namespace ParcInformatique.Models;

public partial class TypeMateriel
{
    public int IdTypeMateriel { get; set; }

    public string? NomMateriel { get; set; }

    public virtual ICollection<Matériel> Matériels { get; set; } = new List<Matériel>();
}
