namespace ParcInformatique
{
    public partial class FrmListClient : Form
    {
        public FrmListClient()
        {
            InitializeComponent();
        }

        private void LstBoxClient_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
