﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ParcInformatique.Models;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ParcInformatique
{
    public partial class FrmAjoutModifMateriel : Form
    {
        public FrmAjoutModifMateriel()
        {
            InitializeComponent();
        }

        int id_materiel_encours = -1;
        public FrmAjoutModifMateriel(Matériel materiel)
        {
            InitializeComponent();
            id_materiel_encours = materiel.IdMateriel;

            textBox1.Text = materiel.NomMachine.ToString();
            textBox2.Text = materiel.AdresseIp.ToString();
            textBox3.Text = materiel.Description.ToString();
            dateTimePicker1.Value = materiel.DateMiseEnService;
        }

        private void FrmAjoutModifMateriel_Load(object sender, EventArgs e)
        {

        }

        private void BtnModifMateriel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnAddMateriel_Click(object sender, EventArgs e)
        {
            if (id_materiel_encours == -1)
            {
                try
                {
                    using var db = new ParcInforYounessMaximeContext();

                    var client = new Matériel
                    {
                        NomMachine = textBox1.Text,
                        AdresseIp = textBox2.Text,
                        Description = textBox3.Text,
                        DateMiseEnService = dateTimePicker1.Value
                    };

                    db.Matériels.Add(client);
                    db.SaveChanges();

                    MessageBox.Show("Matériel ajouté avec succès ");
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de l'ajout du Matériel : " + ex.Message);
                }

            }
            else
            {
                using (ParcInforYounessMaximeContext db = new ParcInforYounessMaximeContext())
                {
                    Matériel materiel = db.Matériels.Single(o => o.IdMateriel == id_materiel_encours);

                    materiel.NomMachine = textBox1.Text;
                    materiel.AdresseIp = textBox2.Text;
                    materiel.Description = textBox3.Text;

                    db.Matériels.Update(materiel);
                    db.SaveChanges();
                    this.Close();
                }
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
