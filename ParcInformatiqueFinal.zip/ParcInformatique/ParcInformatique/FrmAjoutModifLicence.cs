﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ParcInformatique.Models;

namespace ParcInformatique
{
    public partial class FrmAjoutModifLicence : Form
    {
        public FrmAjoutModifLicence()
        {
            InitializeComponent();
        }

        int id_licence_encours = -1;
        public FrmAjoutModifLicence(LicenceLogiciel licence)
        {
            InitializeComponent();
            id_licence_encours = licence.IdClient;

            textBox1.Text = licence.NomProduit.ToString();
            textBox2.Text = licence.CleProduit.ToString();
            dateTimePicker1.Value = licence.DateExpiration;

        }

        private void FrmAjoutModifLicence_Load(object sender, EventArgs e)
        {

        }

        private void BtnAddLicence_Click(object sender, EventArgs e)
        {
            if (id_licence_encours == -1)
            {
                try
                {
                    using var db = new ParcInforYounessMaximeContext();

                    var licence = new LicenceLogiciel
                    {
                        NomProduit = textBox1.Text,
                        CleProduit = textBox2.Text,
                        DateExpiration = dateTimePicker1.Value
                    };

                    db.LicenceLogiciels.Add(licence);
                    db.SaveChanges();

                    MessageBox.Show("Licence ajouté avec succès ");
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de l'ajout de la licence : " + ex.Message);
                }

            }
            else
            {
                // Ouvrir le contexte, charger le client existant, affecter les propriété du client et faire la sauvegarde
                using (ParcInforYounessMaximeContext db = new ParcInforYounessMaximeContext())
                {
                    LicenceLogiciel licence = db.LicenceLogiciels.Single(o => o.IdLicence == id_licence_encours);

                    licence.NomProduit = textBox1.Text;
                    licence.CleProduit = textBox2.Text;
                    dateTimePicker1.Value = licence.DateExpiration;
                    //licence.DateExpiration = textBox.Text;

                    db.LicenceLogiciels.Update(licence);
                    db.SaveChanges();
                    this.Close();
                }
            }
        }

        private void BtnModifLicence_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
