﻿using System;
using System.Collections.Generic;

namespace ParcInformatique.Models;

public partial class LicenceLogiciel
{
    public int IdLicence { get; set; }

    public string? NomProduit { get; set; }

    public string? CleProduit { get; set; }

    public DateTime? DateExpiration { get; set; }

    public int IdClient { get; set; }

    public virtual Client IdClientNavigation { get; set; } = null!;
}
