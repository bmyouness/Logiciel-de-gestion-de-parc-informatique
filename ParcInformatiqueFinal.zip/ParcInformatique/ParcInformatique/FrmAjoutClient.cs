﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ParcInformatique.Models;

namespace ParcInformatique
{
    public partial class FrmAjoutClient : Form
    {
        public FrmAjoutClient()
        {
            InitializeComponent();
        }

        int id_client_encours = -1;
        public FrmAjoutClient(Client client)
        {
            InitializeComponent();
            id_client_encours = client.IdClient;

            TxtBoxSiret.Text = client.Siret.ToString();
            TxtBoxEntreprise.Text = client.NomEntreprise.ToString();
            TxtBoxJuridique.Text = client.FormeJuridique.ToString();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FrmAjoutClient_Load(object sender, EventArgs e)
        {

        }

        private void BtnAddClient_Click(object sender, EventArgs e)
        {
            if (id_client_encours == -1)
            {
                try
                {
                    using var db = new ParcInforYounessMaximeContext();

                    var client = new Client
                    {
                        Siret = TxtBoxSiret.Text,
                        NomEntreprise = TxtBoxEntreprise.Text,
                        FormeJuridique = TxtBoxJuridique.Text
                    };

                    db.Clients.Add(client);
                    db.SaveChanges();

                    MessageBox.Show("Client ajouté avec succès ");
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de l'ajout du client : " + ex.Message);
                }

            }
            else
            {
                // Ouvrir le contexte, charger le client existant, affecter les propriété du client et faire la sauvegarde
                using (ParcInforYounessMaximeContext db = new ParcInforYounessMaximeContext())
                {
                    Client client = db.Clients.Single(o => o.IdClient == id_client_encours);

                    client.Siret = TxtBoxSiret.Text;
                    client.NomEntreprise = TxtBoxEntreprise.Text;
                    client.FormeJuridique = TxtBoxJuridique.Text;

                    db.Clients.Update(client);
                    db.SaveChanges();
                    this.Close();
                }
            }
        }

        private void BtnAnnuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
