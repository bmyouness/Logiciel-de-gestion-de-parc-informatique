﻿namespace ParcInformatique
{
    partial class FrmListClient
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LstBoxClient = new ListBox();
            TxtLstClient = new Label();
            BtnAjoutClient = new Button();
            BtnModifClient = new Button();
            BtnSuppClient = new Button();
            SuspendLayout();
            // 
            // LstBoxClient
            // 
            LstBoxClient.FormattingEnabled = true;
            LstBoxClient.Location = new Point(139, 124);
            LstBoxClient.Name = "LstBoxClient";
            LstBoxClient.Size = new Size(224, 224);
            LstBoxClient.TabIndex = 0;
            LstBoxClient.SelectedIndexChanged += LstBoxClient_SelectedIndexChanged;
            LstBoxClient.DoubleClick += LstBoxClient_DoubleClick;
            // 
            // TxtLstClient
            // 
            TxtLstClient.AutoSize = true;
            TxtLstClient.Location = new Point(195, 61);
            TxtLstClient.Name = "TxtLstClient";
            TxtLstClient.Size = new Size(96, 20);
            TxtLstClient.TabIndex = 1;
            TxtLstClient.Text = "Listes CLients";
            // 
            // BtnAjoutClient
            // 
            BtnAjoutClient.Location = new Point(587, 124);
            BtnAjoutClient.Name = "BtnAjoutClient";
            BtnAjoutClient.Size = new Size(94, 40);
            BtnAjoutClient.TabIndex = 2;
            BtnAjoutClient.Text = "Ajouter";
            BtnAjoutClient.UseVisualStyleBackColor = true;
            BtnAjoutClient.Click += button1_Click;
            // 
            // BtnModifClient
            // 
            BtnModifClient.Location = new Point(587, 209);
            BtnModifClient.Name = "BtnModifClient";
            BtnModifClient.Size = new Size(94, 40);
            BtnModifClient.TabIndex = 3;
            BtnModifClient.Text = "Modifier";
            BtnModifClient.UseVisualStyleBackColor = true;
            BtnModifClient.Click += button2_Click;
            // 
            // BtnSuppClient
            // 
            BtnSuppClient.Location = new Point(587, 308);
            BtnSuppClient.Name = "BtnSuppClient";
            BtnSuppClient.Size = new Size(94, 40);
            BtnSuppClient.TabIndex = 4;
            BtnSuppClient.Text = "Supprimer";
            BtnSuppClient.UseVisualStyleBackColor = true;
            BtnSuppClient.Click += BtnSuppClient_Click;
            // 
            // FrmListClient
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BtnSuppClient);
            Controls.Add(BtnModifClient);
            Controls.Add(BtnAjoutClient);
            Controls.Add(TxtLstClient);
            Controls.Add(LstBoxClient);
            Name = "FrmListClient";
            Text = "Form1";
            Load += FrmListClient_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox LstBoxClient;
        private Label TxtLstClient;
        private Button BtnAjoutClient;
        private Button BtnModifClient;
        private Button BtnSuppClient;
    }
}
