﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ParcInformatique.Models;

namespace ParcInformatique
{
    public partial class FrmListMaterielLicences : Form
    {
        public FrmListMaterielLicences()
        {
            InitializeComponent();
            ChargerLaListeMateriel();
            ChargerLaListeLicence();
        }

        public static int IdMaterielClient
        {
            get;
            private set;
        }

        private void ChargerLaListeLicence()
        {
            try
            {
                LicenceLogiciel selectedLicenceLogiciel = (LicenceLogiciel)listBox2.SelectedItem;

                listBox2.Items.Clear();
                using (ParcInforYounessMaximeContext db = new ParcInforYounessMaximeContext())
                {
                    List<LicenceLogiciel> LicenceLogiciel = db.LicenceLogiciels.ToList();
                    listBox2.DisplayMember = "NomProduit"; // On affiche le nom et le prénom de l'entreprise à l'utilisateur
                    listBox2.Items.AddRange(LicenceLogiciel.ToArray()); // Conversion de la liste en tableau
                }

                listBox2.SelectedItem = listBox2.Items.OfType<LicenceLogiciel>().Where(o => o.IdLicence == selectedLicenceLogiciel?.IdLicence).SingleOrDefault();

            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }



        private void ChargerLaListeMateriel()
        {
            try
            {
                Matériel selectedMateriel = (Matériel)listBox1.SelectedItem;

                listBox1.Items.Clear();
                using (ParcInforYounessMaximeContext db = new ParcInforYounessMaximeContext())
                {
                    List<Matériel> matériels = db.Matériels.ToList();
                    listBox1.DisplayMember = "NomMachine"; // On affiche le nom et le prénom de l'entreprise à l'utilisateur
                    listBox1.Items.AddRange(matériels.ToArray()); // Conversion de la liste en tableau
                }

                listBox1.SelectedItem = listBox1.Items.OfType<Matériel>().Where(o => o.IdMateriel == selectedMateriel?.IdMateriel).SingleOrDefault();

            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnAjout_Click(object sender, EventArgs e)
        {
            FrmAjoutModifMateriel add_client = new FrmAjoutModifMateriel();
            add_client.Show();
            ChargerLaListeMateriel();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void BtnModifMateriel_Click(object sender, EventArgs e)
        {
            Matériel selectedMateriel = (Matériel)listBox1.SelectedItem;
            IdMaterielClient = selectedMateriel.IdMateriel;
            FrmAjoutModifMateriel add_client = new FrmAjoutModifMateriel(selectedMateriel);
            add_client.Show();
            ChargerLaListeMateriel();
        }

        private void BtnSuppressionMateriel_Click(object sender, EventArgs e)
        {
            Matériel selectedMateriel = (Matériel)listBox1.SelectedItem;

            DialogResult dr = MessageBox.Show(
                "Êtes-vous sûr de vouloir supprimer " + selectedMateriel.NomMachine + " ?",
                "Êtes-vous sûr ?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dr == DialogResult.Yes)
            {
                try
                {
                    using (var db = new ParcInforYounessMaximeContext())
                    {
                        // Attache l’entité sélectionnée puis supprime
                        db.Matériels.Attach(selectedMateriel);
                        db.Matériels.Remove(selectedMateriel);
                        db.SaveChanges();
                    }

                    // Recharge la liste après suppression
                    ChargerLaListeMateriel();
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void BtnSupprLicence_Click(object sender, EventArgs e)
        {
            LicenceLogiciel selectedLicence = (LicenceLogiciel)listBox2.SelectedItem;

            DialogResult dr = MessageBox.Show(
                "Êtes-vous sûr de vouloir supprimer " + selectedLicence.NomProduit + " ?",
                "Êtes-vous sûr ?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dr == DialogResult.Yes)
            {
                try
                {
                    using (var db = new ParcInforYounessMaximeContext())
                    {
                        // Attache l’entité sélectionnée puis supprime
                        db.LicenceLogiciels.Attach(selectedLicence);
                        db.LicenceLogiciels .Remove(selectedLicence);
                        db.SaveChanges();
                    }

                    // Recharge la liste après suppression
                    ChargerLaListeMateriel();
                }
                catch (Exception ex)
                {

                }
            }
        }
    }
}
